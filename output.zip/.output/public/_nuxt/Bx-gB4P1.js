import"./D1XFjxR0.js";const s=globalThis.setInterval;export{s};
